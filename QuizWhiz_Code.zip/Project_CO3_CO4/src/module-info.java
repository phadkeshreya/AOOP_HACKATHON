/**
 * 
 */
/**
 * 
 */
module Project_CO3_CO4 {
	requires java.sql;
	requires java.desktop;
}