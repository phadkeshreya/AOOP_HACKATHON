package com.quizwhiz;

public class TimerThread extends Thread {
	private int timeLimit; // seconds

    public TimerThread(int timeLimit) {
        this.timeLimit = timeLimit;
    }

    @Override
    public void run() {
        try {
            while (timeLimit > 0) {
                System.out.println("Time remaining: " + timeLimit + " seconds");
                timeLimit--;
                Thread.sleep(1000); // 1-second interval
            }
            System.out.println("Time's up!");
        } catch (InterruptedException e) {
            System.out.println("Timer interrupted");
        }
    }
}
