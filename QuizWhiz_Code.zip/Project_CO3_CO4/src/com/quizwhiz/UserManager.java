package com.quizwhiz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

public class UserManager {
    private Connection connection;

    public UserManager(Connection connection) {
        this.connection = connection;
    }

    public boolean registerUser(String username, String password, String email, String dateOfBirth) {
        if (usernameExists(username)) {
            return false; // Username already exists
        }

        // Validate and format the date
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false);
        Date parsedDate;

        try {
            parsedDate = dateFormat.parse(dateOfBirth); // Check if valid
            String formattedDate = dateFormat.format(parsedDate); // Format date for insertion

            String sql = "INSERT INTO user_profiles (username, password, email, date_of_birth) VALUES (?, ?, ?, ?::date)";
            try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
                pstmt.setString(1, username);
                pstmt.setString(2, hashPassword(password)); // Hash the password
                pstmt.setString(3, email);
                pstmt.setString(4, formattedDate); // Use formatted date
                pstmt.executeUpdate();
                return true; // Registration successful
            }
        } catch (ParseException e) {
            e.printStackTrace();
            // Handle invalid date format
            JOptionPane.showMessageDialog(null, "Invalid date format. Please use YYYY-MM-DD.");
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Registration failed
        }
    }

    private boolean usernameExists(String username) {
        String sql = "SELECT COUNT(*) FROM user_profiles WHERE username = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0; // Check if username exists
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Username does not exist
    }

    public boolean validateUser(String username, String password) {
        String sql = "SELECT password FROM user_profiles WHERE username = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String storedPassword = rs.getString("password");
                return storedPassword.equals(hashPassword(password)); // Validate password
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // User does not exist or password is incorrect
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }
}
