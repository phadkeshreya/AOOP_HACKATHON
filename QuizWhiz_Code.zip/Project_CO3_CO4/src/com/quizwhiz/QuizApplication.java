package com.quizwhiz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class QuizApplication {
    private DatabaseManager dbManager = new DatabaseManager();
    private JFrame frame;
    private JLabel questionLabel;
    private JTextField answerField;
    private JLabel timerLabel;
    private JButton submitButton;
    private JLabel scoreLabel;
    private Timer timer;
    private int timeLeft = 10; // 10 seconds for each question
    private int correctAnswers = 0;
    private String selectedCategory; // The chosen quiz category
    private String currentUser; // To track logged-in user

    public QuizApplication() {
        frame = new JFrame("Quiz Application");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new GridLayout(5, 1));

        showLoginOrRegistration();

        frame.setVisible(true);
    }

    private void showLoginOrRegistration() {
        // Show options to log in or create a new user
        Object[] options = {"Login", "Create User"};
        int choice = JOptionPane.showOptionDialog(
                frame, "Welcome to QuizWhiz! Please choose an option:",
                "Login or Create User", JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        if (choice == 0) { // Login option
            openLoginDialog();
        } else if (choice == 1) { // Create User option
            openRegistrationDialog();
        } else {
            System.exit(0); // Exit if the dialog is closed
        }
    }

    private void openLoginDialog() {
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();

        Object[] message = {
                "Username:", usernameField,
                "Password:", passwordField
        };

        int option = JOptionPane.showConfirmDialog(frame, message, "Login", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            // Validate user credentials
            UserManager userManager = new UserManager(dbManager.getConnection());
            if (userManager.validateUser(username, password)) {
                currentUser = username;
                JOptionPane.showMessageDialog(frame, "Login successful!");
                showCategorySelection(); // Proceed to category selection
            } else {
                JOptionPane.showMessageDialog(frame, "Login failed! Invalid credentials.");
                openLoginDialog(); // Retry login
            }
        }
    }

    private void showCategorySelection() {
        // Show options to select a quiz category
        String[] options = {"Country-Capital", "Basic Mathematics"};
        selectedCategory = (String) JOptionPane.showInputDialog(
                null, "Select Quiz Category", "Category Selection",
                JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        // If the user cancels, exit the application
        if (selectedCategory == null) {
            System.exit(0);
        } else {
            startQuiz(); // Start the quiz after category selection
        }
    }

    public void startQuiz() {
        String question = dbManager.getRandomQuestion(selectedCategory);

        // Reset UI components for the quiz
        questionLabel = new JLabel(question, SwingConstants.CENTER);
        answerField = new JTextField();
        timerLabel = new JLabel("Time Left: " + timeLeft, SwingConstants.CENTER);
        submitButton = new JButton("Submit Answer");
        scoreLabel = new JLabel("Score: " + correctAnswers, SwingConstants.CENTER);

        // Set up the frame layout for the quiz
        frame.getContentPane().removeAll();
        frame.setLayout(new GridLayout(5, 1));
        frame.add(questionLabel);
        frame.add(answerField);
        frame.add(timerLabel);
        frame.add(submitButton);
        frame.add(scoreLabel);
        frame.revalidate();
        frame.repaint();

        // Start the countdown timer
        startTimer();

        // Set up the button click event
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkAnswer();
            }
        });

        // Add key listener to the answer field
        answerField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    checkAnswer();
                }
            }
        });
    }

    private void startTimer() {
        timeLeft = 10; // Reset timer
        timerLabel.setText("Time Left: " + timeLeft);

        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (timeLeft > 0) {
                    timeLeft--;
                    timerLabel.setText("Time Left: " + timeLeft);
                } else {
                    timer.stop();
                    JOptionPane.showMessageDialog(frame, "Time's up! The correct answer was: " + dbManager.getCorrectAnswer(questionLabel.getText()));
                    startQuiz(); // Start the next question
                }
            }
        });
        timer.start();
    }

    private void checkAnswer() {
        String question = questionLabel.getText();
        String userAnswer = answerField.getText();
        String correctAnswer = dbManager.getCorrectAnswer(question);

        if (correctAnswer != null && userAnswer.equalsIgnoreCase(correctAnswer)) {
            correctAnswers++;
            JOptionPane.showMessageDialog(frame, "Correct answer!");
        } else {
            JOptionPane.showMessageDialog(frame, "Incorrect answer! The correct answer was: " + correctAnswer);
        }

        // Update the score label
        scoreLabel.setText("Score: " + correctAnswers);

        timer.stop();
        startQuiz(); // Start the next question
    }

    private void openRegistrationDialog() {
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JTextField emailField = new JTextField();
        JTextField dobField = new JTextField(); // Format: YYYY-MM-DD

        Object[] message = {
                "Username:", usernameField,
                "Password:", passwordField,
                "Email:", emailField,
                "Date of Birth (YYYY-MM-DD):", dobField
        };

        int option = JOptionPane.showConfirmDialog(frame, message, "Create User", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String email = emailField.getText();
            String dateOfBirth = dobField.getText();

            UserManager userManager = new UserManager(dbManager.getConnection());
            if (userManager.registerUser(username, password, email, dateOfBirth)) {
                JOptionPane.showMessageDialog(frame, "User registered successfully!");
                openLoginDialog(); // Automatically log in the new user
            } else {
                JOptionPane.showMessageDialog(frame, "Registration failed! Username already exists.");
                openRegistrationDialog(); // Retry registration
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new QuizApplication());
    }
}
