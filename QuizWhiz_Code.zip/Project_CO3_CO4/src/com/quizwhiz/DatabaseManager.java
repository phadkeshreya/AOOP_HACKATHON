package com.quizwhiz;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseManager {
    private static final String URL = "jdbc:postgresql://localhost:5432/quizwhiz";
    private static final String USER = "postgres";      // Replace with your PostgreSQL username
    private static final String PASSWORD = "12345";     // Replace with your PostgreSQL password

    private Connection connection;

    // Method to initialize connection
    public DatabaseManager() {
        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connected to the PostgreSQL server successfully.");
        } catch (SQLException e) {
            System.out.println("Failed to connect to PostgreSQL server.");
            e.printStackTrace();
        }
    }

    // Method to fetch a random question from a specific category
 // Method to fetch a random question from a specific category
    public String getRandomQuestion(String category) {
        String questionText = null;
        String query;

        // Determine the table based on the category
        if (category.equalsIgnoreCase("country-capital")) {
            query = "SELECT question_text FROM questions ORDER BY RANDOM() LIMIT 1";
        } else if (category.equalsIgnoreCase("basic mathematics")) { // Updated to match exactly
            query = "SELECT question_text FROM math_questions ORDER BY RANDOM() LIMIT 1";
        } else {
            throw new IllegalArgumentException("Unknown category: " + category);
        }

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                questionText = rs.getString("question_text");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return questionText;
    }


    // Method to fetch the correct answer based on the question text
    public String getCorrectAnswer(String question) {
        String correctAnswer = null;
        String queryCountryCapital = "SELECT correct_answer FROM questions WHERE question_text = ?";
        String queryMath = "SELECT correct_answer FROM math_questions WHERE question_text = ?";

        try {
            // Determine the correct table by checking both tables
            try (PreparedStatement stmtCountryCapital = connection.prepareStatement(queryCountryCapital)) {
                stmtCountryCapital.setString(1, question);
                ResultSet rsCountryCapital = stmtCountryCapital.executeQuery();
                if (rsCountryCapital.next()) {
                    correctAnswer = rsCountryCapital.getString("correct_answer");
                }
            }

            if (correctAnswer == null) { // Not found in the 'questions' table, check 'math_questions'
                try (PreparedStatement stmtMath = connection.prepareStatement(queryMath)) {
                    stmtMath.setString(1, question);
                    ResultSet rsMath = stmtMath.executeQuery();
                    if (rsMath.next()) {
                        correctAnswer = rsMath.getString("correct_answer");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return correctAnswer; // Return correctAnswer if found, otherwise null
    }

    // Close connection method (optional)
    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Database connection closed.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public Connection getConnection() {
        return connection;
    }

}
